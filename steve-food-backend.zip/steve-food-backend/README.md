# STEVE FOOD — Backend

Backend + baz done pou jere kòmand STEVE FOOD an tan reyèl.

## Sa ki ladan l

- **API REST** pou restoran, meni, kòmand, chofè
- **Baz done SQLite** (yon sèl fichye, pa bezwen enstale sèvè baz done apa)
- **Tan reyèl** ak Socket.IO: lè yon kliyan fè yon kòmand, li parèt imedyatman nan paj admin
- **Paj Admin** (`/admin.html`) pou wè kòmand yo, konfime peman manyèl (MonCash/NatCash), chanje estati (preparasyon → chofè pran l → annwout → livre)

## Enstalasyon (sou òdinatè w oswa yon sèvè)

Ou bezwen [Node.js](https://nodejs.org) enstale (vèsyon 18 oswa plis).

```bash
cd steve-food-backend
npm install
cp .env.example .env
```

Louvri `.env` epi mete pwòp `ADMIN_KEY` ou (kle sekrè pou antre nan paj admin la).

Seed baz done a ak restoran/meni yo:

```bash
npm run seed
```

Lanse sèvè a:

```bash
npm start
```

Sèvè a ap kouri sou `http://localhost:4000`.
Paj admin: `http://localhost:4000/admin.html` (antre `ADMIN_KEY` ou mete nan `.env` a).

## Rout API prensipal yo

| Metòd | Rout | Sa li fè |
|---|---|---|
| GET | `/api/restaurants` | Lis tout restoran ak meni yo |
| GET | `/api/restaurants/:id` | Yon sèl restoran ak meni li |
| POST | `/api/orders` | Kreye yon nouvo kòmand |
| GET | `/api/orders/:id` | Detay + estati yon kòmand (pou paj "swiv kòmand") |
| GET | `/api/orders` | (Admin) Tout kòmand yo |
| PATCH | `/api/orders/:id/status` | (Admin) Chanje estati, konfime peman, bay chofè |
| GET | `/api/drivers` | Lis chofè aktif |
| POST | `/api/drivers` | (Admin) Ajoute yon chofè |

### Egzanp: kreye yon kòmand

```bash
curl -X POST http://localhost:4000/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "restaurantId": "lakay",
    "items": [{ "id": "l1", "qty": 2 }, { "id": "l5", "qty": 1 }],
    "customerName": "Widlene",
    "customerPhone": "37123456",
    "address": "Ri Latibonit, Limbé",
    "paymentMethod": "natcash",
    "paymentReference": "TXN-88213"
  }'
```

Sèvè a kalkile pri yo li menm (pa fè konfyans nan pri kliyan an voye), epi li voye evènman `new-order` an tan reyèl bay paj admin la.

## Peman manyèl (MonCash / NatCash)

Pa gen okenn API otomatik konekte — jan nou te dakò a:

1. Kliyan an chwazi MonCash oswa NatCash nan checkout la
2. Kliyan an voye kòb la sou nimewo biznis ou (NatCash: **57258761**)
3. Kliyan an antre yon referans/kapti kòm prèv (`paymentReference`)
4. Ou wè kòmand lan parèt nan paj admin ak "⏳ poko konfime"
5. Ou verifye depo a rive sou kont ou, epi klike **"✅ Konfime Peman"**

## Pwochèn etap pou fè l vin yon vrè sit sou entènèt

1. **Deplwaye backend la**: itilize yon sèvis tankou Railway, Render, oswa Fly.io (yo gen plan gratis pou kòmanse)
2. **Konekte frontend la** (demo React ou genyen deja) ak vrè adrès backend la olye de done ki senile yo
3. **Non domèn**: achte yon non tankou `stevefood.ht` oswa `.com`
4. **Chofè yo**: itilize `/api/drivers` pou anrejistre chofè moto ou yo, epi asiyen yo bay chak kòmand nan paj admin la

## Sekirite

`ADMIN_KEY` nan `.env` a se yon pwoteksyon debaz. Pa pataje l, e chanje l anvan ou mete sit la sou entènèt pou tout moun wè.
